<?php 

 date_default_timezone_set("America/Lima");
  $date = new DateTime();

  $fecha_inicio = $date->format('Y-m-d H:i:s');
  
 ?>


<!DOCTYPE html>
<html lang="es">
<head>
  	<!-- Required meta tags -->
  	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  	<!-- Bootstrap CSS -->
  	<link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Favicon - FIS -->
     <link rel="shortcut icon" href="logo.jpg">

  	<title>ADMIN-Encuestas</title>

    <script type="text/javascript" language="javascript">   
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
        history.go(1);
      };
    </script>

</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
    <a class="navbar-brand" href="javascript:void(0)">Sistema de Encuestas</a>
	  
     
    
	    
    <!--NAVBAR-->
    <!--<div class="collapse navbar-collapse" id="navb">
      <ul class="navbar-nav mr-auto">
      </ul>-->
      <form class="form-inline my-2 my-lg-0" style="color: #fff">
          			          
      <?php   
    session_start();
        if (isset($_SESSION['u_usuario'])) {
          echo "Bienvenido " . $_SESSION['u_usuario'] . "\t";
          

          echo " 
          &nbsp;
           <a href='index.php'><button class='btn btn-info' type='button'>Regresar</button></a>
               &nbsp;
          <a href='formularioregistro.php'><button class='btn btn-info' type='button' >Registrar Usuarios</button></a>
   <button class='navbar-toggler navbar-toggler-right' type='button' data-toggle='collapse' data-target='#navb'>
     <!-- <span class='navbar-toggler-icon'></span>-->
      
                    
			<a href='../cerrar_sesion.php' class='btn btn-danger' style='margin-left: 10px'>Cerrar Sesión</a>
    
    </button>  
          
          
          
          ";
            
        } else {
          header("Location: ../index.php");
        }
       ?>
         
      </form>
     </nav>
  <?php


require("conexion.php");
// Diseñamos el encabezado de la tabla
$data = '
    <table class="table table-bordered table-hover table-condensed">
        <thead class="thead-dark">
            <tr>
                <th>ID encuesta</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Email</th>
                <th>Acciones</th>
            </tr>
        </thead>';

$query = "SELECT * FROM usuarios ORDER BY id_usuario DESC";
$resultado = $con->query($query);

while ($row = $resultado->fetch_assoc()) {
    $data .= '
        <tbody>
            <tr>
                <td>' . $row["id_usuario"] . '</td>
                <td>' . $row["nombres"] . '</td>
                <td>' . $row["apellidos"] . '</td>
                <td>' . $row["email"] . '</td>
                <td><a href="../administrador/editatuser.php ? id=' . $row["id_usuario"] . '">Editar</a></td>
                
            </tr>
        </tbody>';
}


$data .= '</table>';

echo $data;
    ?>
</body>
</html>

