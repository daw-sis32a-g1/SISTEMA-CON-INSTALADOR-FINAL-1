<?php



// Diseñamos el encabezado de la tabla
$data = '
    <table class="table table-bordered table-hover table-condensed">
        <thead class="thead-dark">
            <tr>
                <th>ID encuesta</th>
                <th>Título</th>
                <th width="100">Descripción</th>
                <th>Estado</th>
                <th>Fecha Inicio</th>
                <th>Fecha Final</th>
                <th>Accciones</th>
            </tr>
        </thead>';

$query = "SELECT * FROM usuarios ORDER BY id_usuario DESC";
$resultado = $con->query($query);

while ($row = $resultado->fetch_assoc()) {
    $data .= '
        <tbody>
            <tr>
                <td>' . $row["clave"] . '</td>
                
                <td width="100">' . mb_strimwidth($row["clave"], 0, 30, "...") . '</td>
                <td>' . $row["clave"] . '</td>
                <td>' . $row["clave"] . '</td>
                <td>' . $row["clave"] . '</td>
                
            </tr>
        </tbody>';
}


$data .= '</table>';

echo $data;