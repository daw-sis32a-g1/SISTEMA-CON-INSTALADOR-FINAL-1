<?php

if (isset($_POST['clave']) && isset($_POST['nombres']) && isset($_POST['apellidos']) && isset($_POST['email']) && isset($_POST['id_tipo_usuario'])) {
    // Incluir archivo de conexión a base de datos
    include("conexion.php");

    // Obtener valores
    //$id_usuario = $_POST['id_usuario'];
    $clave		= sha1($_POST['clave']);
    $nombres    = $_POST['nombres'];
    $apellidos 	= $_POST['apellidos'];
    $email 	= $_POST['email'];
    $id_tipo_usuario=$_POST['id_tipo_usuario'];
    $query = "INSERT INTO usuarios (clave, id_usuario, apellidos, email, id_tipo_usuario)
              VALUES ('$clave', '$nombres', '$apellidos', '$email', '$id_tipo_usuario')";


    $resultado = $con->query($query);
    header("location:index.php");
}
?>
