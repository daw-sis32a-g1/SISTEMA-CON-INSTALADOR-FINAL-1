<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Validar formulario - Listasrroja</title>
	<style>
		body{background-color: #264673; box-sizing: border-box; font-family: Arial;}

		form{
			background-color: white;
			padding: 10px;
			margin: 100px auto;
			width: 400px;
		}

		input[type=text], input[type=password]{
			padding: 10px;
			width: 380px;
		}
		input[type="submit"]{
			border: 0;
			background-color: #ED8824;
			padding: 10px 20px;
		}

		.error{
			background-color: #FF9185;
			font-size: 12px;
			padding: 10px;
		}
		.correcto{
			background-color: #A0DEA7;
			font-size: 12px;
			padding: 10px;
		}
	</style>
    <!-- Bootstrap CSS -->
 <link rel="stylesheet" href="../css/bootstrap.min.css">
  <!-- Favicon - FIS -->
  <link rel="shortcut icon" href="imagenes/Logo-fis.jpg">


</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="javascript:void(0)">Sistema de Encuestas</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navb">
          
        <span class="navbar-toggler-icon"></span>
      </button>

     
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                  <a href="login.php"><button class="btn btn-info" type="button">Ingresar</button></a>
          

      <!--NAVBAR-->
      
  </nav>
    <br>
    <br>
	<form action="agregarUsuario.php" method="POST">
		<!--<p>
			Nombre de usuario:<br/>
		<input type="text" name="id_usuario" placeholder="Ingrese sus nombre de usuario" required>

		</p>-->
		<p>
		Nombre de usuario:<br/>
		<input type="text" name="nombres" placeholder="Ingrese sus nombres" required>
		</p>
        
        <p>
		Apellidos:<br/>
		<input type="text" name="apellidos" placeholder="Ingrese sus apellidos" required>
		</p>

		<p>
		Contraseña:<br/>
		<input type="password" name="clave" placeholder="Ingrese su contraseña" required>
		</p>

		<p>
		correo electrónico:<br/>
		<input type="text" name="email" placeholder="Ingrese su e-mail" required>
		</p>
        
        <p>
            <p>
        Tipo de usuario.
        </p>
        <select name="id_tipo_usuario">
            <?php 
             include("conexion.php");

                $query = "SELECT * FROM tipo_usuario";

	$resultado = $con->query($query);
   while($row = $resultado->fetch_assoc()){
                                echo "<option value='".$row["id_tipo_usuario"]."'>".$row["nombre"]."</option>";
                            }
            ?>
            
            </select>

        
		

		<p><input type="submit" value="MODIFICAR"></p> 
	</form>
</body>
</html>
